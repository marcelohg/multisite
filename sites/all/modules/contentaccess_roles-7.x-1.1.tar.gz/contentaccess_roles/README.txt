DESCRIPTION
------------------------------------

The Contentaccess roles module gives node authors the ability to let users in 
selected roles view nodes.

This module is great, if you want to show node teasers on the front page, while 
restricting body access to authorized users.


INSTALLATION DRUPAL 7.x
------------------------------------

When the module have been enabled, it can be configure on the content type 
configuration page. 
Go to Content types >> Add/Edit content type via admin/structure/types.
In the Contentaccess roles settings area, click "Enable" and save.


CONTROLLING VISIBILITY
------------------------------------

Edit content/node you have created and choose which roles can be view it.
